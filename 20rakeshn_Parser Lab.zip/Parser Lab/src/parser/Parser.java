package parser;
import java.io.*;
import java.util.HashMap;

import scanner.ScanErrorException;
import scanner.Scanner;
/**
 * A top-down recursive descent parser that uses grammars and looks ahead tokens.
 * @author RakeshNori
 * @version 3/7/2018
 *
 */
public class Parser 
{
	Scanner sc;
	static String currToken;
	static HashMap<String, Integer> map;
	
	/**
	 * The constructor for a parser that takes in a scanner and creates a 
	 * current Token for parsing through and a map to store variables.
	 * @param s the scanner being passed through into the constructor.
	 * @throws IOException if the BufferedReader in the scanner runs into an error.
	 * @throws ScanErrorException if a scanning error occurs.
	 */
	public Parser(Scanner s) throws IOException, ScanErrorException
	{
		sc = s;
		map = new HashMap<String, Integer>();
		currToken = sc.nextToken();
	}
	
	/**
	 * moves one token ahead in the Scanner. Also checks if the string in the parameter 
	 * is the expected one in currToken.
	 * @param str the String that is expected to be in currToken
	 * @throws IOException if the BufferedReader in the scanner runs into an error.
	 * @throws ScanErrorException if a scanning error occurs.
	 * @throws IllegalArgumentException If currToken and str do not match.
	 * @postcondition the token has moved one ahead.
	 */
	private void eat(String str) throws ScanErrorException, IOException
	{
		if (str.equals(currToken))
		{
			currToken = sc.nextToken();
			if (currToken.equals("mod"))
				currToken = "%";
		}
		else
			throw new IllegalArgumentException("Expected " + str + ", but had " +
												currToken +" instead.");
	}
	
	/**
	 * Parses through a number.
	 * @precondition current token is an integer.
	 * @postcondition the number has been eaten.
	 * @return the value of the parsed int.
	 * @throws IOException if the BufferedReader in the scanner runs into an error.
	 * @throws ScanErrorException if a scanning error occurs.
	 */
	private int parseNumber() throws ScanErrorException, IOException
	{
		int num = 0;
		if (isIdentifier(currToken))
		{
			num = map.get(currToken);
			eat(currToken);
		}
		else
		{
			num = Integer.parseInt(currToken);
			eat(currToken);
		}
		return num;
	}
	
	/**
	 * Parses through a factor, accounting for negative signs and parentheses.
	 * @param num initial value of the number. Should start off as 0 and update through recursion.
	 * @return the value of num after the method finishes.
	 * @precondition initial input for num must be 0.
	 * @throws IOException if the BufferedReader in the scanner runs into an error.
	 * @throws ScanErrorException if a scanning error occurs.
	 * @throws IllegalArgumentException if empty parentheses are present in the text.
	 */
	public int parseFactor(int num) throws ScanErrorException, IOException
	{
		if (currToken.equals("("))
		{
			eat(currToken);
			int val = parseExp();
			eat(")");
			return val;
		}
		else if (currToken.equals("-"))
		{
			eat(currToken);
			if (num == 0)
				num = 1;
			return parseFactor(num * -1);
		}
		else if (currToken.equals(")"))
		{
			throw new IllegalArgumentException("Empty incorrect ) in the text.");
		}
		else
		{
			if (num == 0)
				num = 1;
			return num * parseNumber();
		}
	}
	
	/**
	 * Parses through a term and accounts for multiplication, division, and mods.
	 * Uses parseFactor as a helper.
	 * @return the value of term.
	 * @throws IOException if the BufferedReader in the scanner runs into an error.
	 * @throws ScanErrorException if a scanning error occurs.
	 */
	public int parseTerm() throws ScanErrorException, IOException
	{
		int init = parseFactor(0);
		//System.out.println(currToken);
		while (currToken.equals("*")|| currToken.equals("/") || currToken.equals("%"))
		{
			if (currToken.equals("*"))
			{
				eat("*");
				init *= parseFactor(0);
			}
			else if (currToken.equalsIgnoreCase("%"))
			{
				eat("%");
				init %= parseFactor(0);
			}
			else
			{
				eat("/");
				init /= parseFactor(0);
			}
		}
		return init;
	}
	
	/**
	 * parses an Expression, accounting for all the operations by using parseTerm and parseFactor.
	 * @return the value of the expression.
	 * @throws IOException if the BufferedReader in the scanner runs into an error.
	 * @throws ScanErrorException if a scanning error occurs.
	 */
	public int parseExp() throws ScanErrorException, IOException
	{
		int init = parseTerm();
		while (currToken.equals("+") || currToken.equals("-"))
		{
			if (currToken.equals("+"))
			{
				eat("+");
				init += parseTerm();
			}
			else
			{
				eat("-");
				init -= parseTerm();
			}
		}
		return init; 
	}
	
	/**
	 * Checks if a given token is an identifier or not.
	 * @param s the token being checked for being an identifier
	 * @return true if it is an identifier; otherwise,
	 * 		   false.
	 */
	private boolean isIdentifier(String s)
	{
		char input = s.charAt(0); 
		if ((input >= 'A' && input <= 'Z') || (input >= 'a' && input <= 'z'))
		{
			for (int i = 1; i < currToken.length(); i++)
			{
				input = s.charAt(i);
				if (!((input >= 'A' && input <= 'Z') || (input >= 'a' && input <= 'z')
					|| (input >= '0' && input <= '9')))
					return false;
			}
			return true;
		}
		return false;
	}
	
	/**
	 * Parses the whole text file and prints the output.
	 * @throws IOException if the BufferedReader in the scanner runs into an error.
	 * @throws ScanErrorException if a scanning error occurs.
	 */
	public void parseStatement() throws ScanErrorException, IOException
	{
		if (currToken.equals("WRITELN"))
		{
			eat("WRITELN");
			eat("(");
			int n = parseExp();
			eat(")");
			eat(";");
			System.out.println(n);
		}
		else if (currToken.equals("BEGIN"))
		{
			eat("BEGIN");
			while (!currToken.equals("END"))
			{
				if (currToken.equals("EOF"))
					throw new IllegalArgumentException("No END statement.");
				else if (currToken.equals("BEGIN"))
					parseStatement();
				else if(currToken.equals("WRITELN"))
				{
					eat("WRITELN");
					eat("(");
					int n = parseExp();
					eat(")");
					eat(";");
					System.out.println(n);
				}
				else if (isIdentifier(currToken))
				{
					String x = currToken;
					eat(x);
					eat(":=");
					int val = parseExp();
					map.put(x, val);
					eat(";");
				}
			}
		}
	}
	
	/**
	 * The main method that creates a parser for the ParserTest.txt file.
	 * @param args the arguments from the command line.
	 * @throws IOException if the BufferedReader in the scanner runs into an error.
	 * @throws ScanErrorException if a scanning error occurs.
	 */
	public static void main(String [] args) throws IOException, ScanErrorException
	{
		FileInputStream inStream = new FileInputStream(new File("ParserTest4.txt"));
    	Scanner sc = new Scanner(inStream);
		Parser p = new Parser(sc);
		p.parseStatement();
		
	}
}
