package ast;

import java.util.List;

import environment.Environment;

/**
 * The Procedure Call class is responsible for executing a Procedure 
 * with the corresponding name and parameters as declared in the object.
 * @author Rakesh Nori
 * @version 4/6/2018
 */
public class ProcedureCall extends Expression
{
	private String s;
	private List<Expression> exps;
	
	/**
	 * Makes a new ProcedureCall object with the String 
	 * that represents a procedure that was already declared.
	 * @param name the String representing the declared Procedure to be executed.
	 * @param params the parameters of the procedure being passed in.
	 */
	public ProcedureCall(String name, List<Expression> params)
	{
		s = name;
		exps = params;
	}
	
	/**
	 * Evaluates the Procedure Call and sets the values of all the arguments.
	 * by taking the resulting statement from the declaration and executing it.
	 * @return the value of the variable associated with the procedure call.
	 * @param env the environment that the current call is in.
	 */
	public int eval (Environment env)
	{
		Environment child = new Environment(env);
		child.declareVariable(s, 0);
		ProcedureDeclaration a = child.proGet(s);
		List<String> corr = a.getArgs();
		if (corr != null && exps != null)
		{
			if (corr.size() != exps.size())
				throw new IllegalArgumentException("Parameters stated "
						+ "in the declaration of the method "
						+ "do not match arguments given.");
			for (int i = 0; i < corr.size(); i++)
				child.declareVariable(corr.get(i), exps.get(i).eval(env));
		}
		a.getBody().exec(child);
	    return child.getVariable(s);
	}
}
