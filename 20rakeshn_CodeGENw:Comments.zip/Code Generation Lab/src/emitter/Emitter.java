package emitter;
import java.io.*;

/**
 * The Emitter is responsible for outputting MIPS code to a different file
 * that can compile and have the same functionality as the current program.
 * @author Rakesh Nori
 * @version 4/20/2018
 */
public class Emitter
{
	private PrintWriter out;
	private int start = 1;
	private int loopstart = 1;
	private int loopend = 1;

	/**
	 * Creates a new Emitter object.
	 * @param outputFileName the name of the output file.
	 */
	public Emitter(String outputFileName)
	{
		try
		{
			out = new PrintWriter(new FileWriter(outputFileName), true);
		}
		catch(IOException e)
		{
			throw new RuntimeException(e);
		}
	}

	/**
	 * prints one line of code to file (with non-labels indented)
	 * @param code the MIPS code.
	 */
	public void emit(String code)
	{
		if (!code.endsWith(":"))
			code = "\t" + code;
		out.println(code);
	}

	/**
	 * pushes the value of a register on to a stack.
	 * @param reg the register being pushed on to the stack.
	 */
	public void emitPush(String reg)
	{
		emit("subu $sp, $sp, 4" + "  #stores register " + reg +" onto the stack.");
		emit("sw " + reg +", ($sp)");
	}
	
	/**
	 * Pops a value off the stack and on to the register.
	 * @param reg the register that will contain the value that was popped off the stack.
	 */
	public void emitPop(String reg)
	{
		emit("lw " + reg +", ($sp)" + "  #removes register " + reg + " from the stack.");
		emit("addu $sp, $sp, 4");
	}
	/**
	 * Closes the file after all emit calls have been completed.
	 */
	public void close()
	{
		out.close();
	}
	
	/**
	 * Gets the next label number for an if statement.
	 * @return the next available if label number.
	 */
	public int nextLabelID()
	{
		int ret = start;
		start++;
		return ret;
	}
	
	/**
	 * Gets the next label number for a loop statement.
	 * @return the next available loop label number.
	 */
	public int loopLabelID()
	{
		int ret = loopstart;
		loopstart++;
		return ret;
	}
	
	/**
	 * Gets the next label number for an endLoop.
	 * @return the next available end loop label number.
	 * @return
	 */
	public int endLoopLabelID()
	{
		int ret = loopend;
		loopend++;
		return ret;
	}
}