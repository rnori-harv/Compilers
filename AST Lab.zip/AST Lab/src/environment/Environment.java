package environment;

import java.util.HashMap;

/**
 * The Environment class is responsible for Storing and setting the values of
 * Variables through its HashMap.
 * @author Rakesh Nori
 * @version 3/20/2018
 */
public class Environment 
{
	private HashMap<String, Integer> map;
	
	/**
	 * Instantiates the Map object by making it a new HashMap that uses 
	 * String and Integers 
	 * for the Key Value pair.
	 */
	public Environment()
	{
		 map = new HashMap<String, Integer>();
	}
	/**
	 * Associates the given variable name with the given value
	 * @param variable name of the variable
	 * @param value its value
	 */
	public void setVariable(String variable, int value)
	{
		map.put(variable, value);
	}
	
	/**
	 * Gets the value of the variable corresponding to its name.
	 * @param name the name of the variable that is to be retrieved.
	 * @return the Integer value of the String key that was given.
	 */
	public int getVariable(String name)
	{
		return map.get(name);
	}
	
}
