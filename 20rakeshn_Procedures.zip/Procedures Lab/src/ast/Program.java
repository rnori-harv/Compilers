package ast;

import java.util.List;

import environment.Environment;

/**
 * The Program class holds Procedures and Statements that are contained
 * in a program. It executes all of them when called upon.
 * @author Rakesh Nori
 * @version 4/5/2018
 */
public class Program extends Statement
{
	private List <ProcedureDeclaration> proceds;
	private Statement s;
	
	/**
	 * Establishes all the procedures and Statements in the program.
	 * @param in the list of Procedures
	 * @param f the Statement(s) called.
	 */
	public Program(List <ProcedureDeclaration> in, Statement f)
	{
		proceds = in;
		s = f;
	}
	
	/**
	 * Executes all the procedure declarations and the statement after, 
	 * which is basically the same thing as running the program.
	 * @param env the Global environment in which the program will be executed in.
	 */
	public void exec(Environment env)
	{
		for (ProcedureDeclaration p : proceds)
			p.exec(env);
		s.exec(env);
	}
}
