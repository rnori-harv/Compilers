package ast;
import environment.Environment;
/**
 * The BinOp class manages operators like +, -, and % 
 * between the values of two expressions.
 * 
 * @author Rakesh Nori
 * @version 3/20/2018
 */
public class BinOp extends Expression
{
	private String op;
	private Expression exp1;
	private Expression exp2;
	/**
	 * The constructor for BinOp
	 * @param in the actual operand that identifies the expression to be used 
	 * 		  (ex: "*", "/")
	 * @param a the first / left expression of the BinOp.
	 * @param b the second / right expression of the BinOp.
	 */
	public BinOp(String in, Expression a, Expression b) 
	{
		op = in;
		exp1 = a;
		exp2 = b;
	}
	
	/**
	 * @Override
	 * Identifies the binary operator being used and uses it to evaluate the two expressions.
	 * @param env the environment containing variables that can be used.
	 * @return the Integer result between the two expressions after 
	 * 		   the operator has been used.
	 */
	public int eval(Environment env)
	{
		if (op.equals("%"))
			return (exp1).eval(env) % (exp2).eval(env);
		else if (op.equals("*"))
			return (exp1).eval(env) * (exp2).eval(env);
		else if (op.equals("/"))
			return (exp1).eval(env) /(exp2).eval(env);
		else if (op.equals("-"))
			return (exp1).eval(env) - (exp2).eval(env);
		else if (op.equals("+"))
			return (exp1).eval(env) + (exp2).eval(env);
		else return 0;
	}
}
