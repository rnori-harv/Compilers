package ast;

import java.util.List;

import environment.Environment;

/**
 * The ProcedureDeclaration class deals with the declaration of procedures 
 * before the program begins. It sets them into its environment's map, 
 * which can be used for the ProcedureCalls in the later statements.
 * @author Rakesh Nori
 * @version 4/6/2018
 */
public class ProcedureDeclaration extends Statement
{
	private String nm;
	private Statement body;
	private List<String> args;
	/**
	 * Creates a new ProcedureDeclaration object that has a name 
	 * (used as a key in the map), body statement, and a list of arguments.
	 * @param id the name of the Procedure
	 * @param in the body of the Procedure
	 * @param a the list of arguments needed for the procedure.
	 */
	public ProcedureDeclaration(String id, Statement in, List<String> a)
	{
		nm = id;
		body = in;
		args = a;
	}
	
	/**
	 * Retrieves the arguments of the Procedure.
	 * @return the list of String arguments.
	 */
	public List<String> getArgs()
	{
		return args;
	}
	/**
	 * Retrieves the body of the procedure.
	 * @return the statement that represents the action the procedure takes.
	 */
	public Statement getBody()
	{
		return body;
	}
	
	/**
	 * Sets the procedure in the environment's HashMap.
	 * @param a the environment being used.
	 */
	public void exec(Environment a)
	{
		a.proSet(nm, this);
	}
}
