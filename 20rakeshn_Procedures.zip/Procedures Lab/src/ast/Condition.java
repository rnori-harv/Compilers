package ast;

import environment.Environment;

/**
 * The class that is responsible for using a relative operator in order 
 * to return a boolean (1 or 0) that describes the relation between two expressions.
 * @author Rakesh Nori
 * @version 3/20/2018
 *
 */
public class Condition extends Expression
{
	private Expression e1;
	private Expression e2;
	private String relop;
	/**
	 * Instantiates the expressions and the relative operator being used in the
	 * Condition object.
	 * @param a the first Expression being compared.
	 * @param op the String representing the relative operator being used.
	 * @param b the second Expression being compared.
	 */
	public Condition(Expression a, String op, Expression b)
	{
		e1 = a;
		relop = op;
		e2 = b;
	}
	
	/**
	 * @Override
	 * Evaluates the two expressions determines their relation.
	 * @param env the Environment containing all the variables that can be used.
	 * @return The boolean result of the expression in form of an integer
	 * 		   (1 = true, 0 = false).
	 */
	public int eval(Environment env)
	{
		if (relop.equals("="))
		{
			if (e1.eval(env) == e2.eval(env))
				return 1;
		}
		else if (relop.equals("<>"))
		{
			if (e1.eval(env) != e2.eval(env))
				return 1;
		}
		else if (relop.equals("<"))
		{
			if (e1.eval(env) < e2.eval(env))
				return 1;
		}
		else if (relop.equals(">"))
		{
			if (e1.eval(env) > e2.eval(env))
				return 1;
		}
		else if (relop.equals("<="))
		{
			if (e1.eval(env) <= e2.eval(env))
				return 1;
		}
		else if (relop.equals(">="))
		{
			if (e1.eval(env) >= e2.eval(env))
				return 1;
		}
		return 0;
	}
}
